-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 22, 2018 at 03:27 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `reksafund`
--

DELIMITER $$
--
-- Procedures
--
CREATE PROCEDURE `access_admin_bank` (IN `email` VARCHAR(50), IN `password` VARCHAR(200))  NO SQL
BEGIN
SET @password = (SELECT admin_bank.password FROM admin_bank WHERE admin_bank.email = email);
    IF ((sha1(md5(password(crc32(hex(password)))))) = @password) THEN
        SELECT admin_bank.id AS id, admin_bank.nama AS nama FROM admin_bank WHERE admin_bank.email = email;
    END IF;
END$$

CREATE PROCEDURE `access_admin_reksadana` (IN `email` VARCHAR(50), IN `password` VARCHAR(200))  NO SQL
BEGIN
SET @password = (SELECT admin_reksadana.password FROM admin_reksadana WHERE admin_reksadana.email = email);
    IF ((sha1(md5(password(crc32(hex(password)))))) = @password) THEN
        SELECT admin_reksadana.id AS id, admin_reksadana.nama AS nama FROM admin_reksadana WHERE admin_reksadana.email = email;
    END IF;
END$$

CREATE PROCEDURE `access_klien` (IN `email` VARCHAR(50), IN `password` VARCHAR(200))  NO SQL
BEGIN
SET @password = (SELECT klien.password FROM klien WHERE klien.email = email);
    IF ((sha1(md5(password(crc32(hex(password)))))) = @password) THEN
        SELECT klien.id AS id, klien.nama_pemilik_rekening AS nama FROM klien WHERE klien.email = email;
    END IF;
END$$

CREATE PROCEDURE `update_up_klien` (IN `id_jenis_transaksi` INT(1), IN `id_klien` VARCHAR(200), IN `id_reksadana` INT(30), IN `up` BIGINT(20), IN `id_reksadana_tujuan` INT(30))  NO SQL
BEGIN
IF (id_jenis_transaksi = 1) THEN
	IF ((SELECT COUNT(*) FROM up_klien WHERE up_klien.id_klien = id_klien AND up_klien.id_reksadana = id_reksadana) > 0) THEN
    	UPDATE up_klien SET up_klien.up = up_klien.up + up WHERE up_klien.id_klien = id_klien AND up_klien.id_reksadana = id_reksadana;
    ELSE
    	INSERT INTO up_klien VALUES(id_klien, id_reksadana, up);
    END IF;
ELSEIF (id_jenis_transaksi = 2) THEN
	IF ((SELECT COUNT(*) FROM up_klien WHERE up_klien.id_klien = id_klien AND up_klien.id_reksadana = id_reksadana) > 0) THEN
    	UPDATE up_klien SET up_klien.up = up_klien.up - up WHERE up_klien.id_klien = id_klien AND up_klien.id_reksadana = id_reksadana;
    END IF;
ELSEIF (id_jenis_transaksi = 3) THEN
	IF ((SELECT COUNT(*) FROM up_klien WHERE up_klien.id_klien = id_klien AND up_klien.id_reksadana = id_reksadana) > 0) THEN
    	IF ((SELECT COUNT(*) FROM up_klien WHERE up_klien.id_klien = id_klien AND up_klien.id_reksadana = id_reksadana_tujuan) > 0) THEN
    		UPDATE up_klien SET up_klien.up = up_klien.up - up WHERE up_klien.id_klien = id_klien AND up_klien.id_reksadana = id_reksadana;
            UPDATE up_klien SET up_klien.up = up_klien.up + up WHERE up_klien.id_klien = id_klien AND up_klien.id_reksadana = id_reksadana_tujuan;
        ELSE
        	UPDATE up_klien SET up_klien.up = up_klien.up - up WHERE up_klien.id_klien = id_klien AND up_klien.id_reksadana = id_reksadana;
            INSERT INTO up_klien VALUES(id_klien, id_reksadana_tujuan, up);
        END IF;
    END IF;
END IF;
END$$

--
-- Functions
--
CREATE FUNCTION `random` (`min` BIGINT, `max` BIGINT) RETURNS BIGINT(20) NO SQL
BEGIN
DECLARE random_nab INT(10);
	SET random_nab = ROUND((RAND() * (max-min))+min);
RETURN random_nab;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin_bank`
--

CREATE TABLE `admin_bank` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_bank`
--

INSERT INTO `admin_bank` (`id`, `nama`, `email`, `password`) VALUES
(1, 'adminbank1', 'adminbank@gmail.com', '59cda011f046befdbdef88ec2f0741b57b099aac'),
(2, 'adminbank2', 'adminbank2@gmail.com', '148c4187b14b1a4f922052c525e328b94783d7a2');

-- --------------------------------------------------------

--
-- Table structure for table `admin_reksadana`
--

CREATE TABLE `admin_reksadana` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_reksadana`
--

INSERT INTO `admin_reksadana` (`id`, `nama`, `email`, `password`) VALUES
(1, 'adminreksadana1', 'adminreksadana@gmail.com', '726e422dfdeaec74f028016e323afdbc9e1f22cb');

-- --------------------------------------------------------

--
-- Table structure for table `history_nab`
--

CREATE TABLE `history_nab` (
  `id_reksadana` int(30) NOT NULL,
  `tanggal` date NOT NULL,
  `nab` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history_nab`
--

INSERT INTO `history_nab` (`id_reksadana`, `tanggal`, `nab`) VALUES
(1470349059, '2018-03-12', 1029.68),
(1811434639, '2018-03-12', 1644.95),
(1470349059, '2018-03-13', 1032.59),
(1811434639, '2018-03-13', 1646.55),
(1470349059, '2018-03-14', 1029.09),
(1811434639, '2018-03-14', 1645.44),
(1470349059, '2018-03-15', 1027.2),
(1811434639, '2018-03-15', 1645.15),
(1470349059, '2018-03-16', 1027.45),
(1811434639, '2018-03-16', 1644.72),
(1470349059, '2018-03-17', 1025.69),
(1811434639, '2018-03-17', 1640.41),
(1470349059, '2018-03-18', 1029.45),
(1811434639, '2018-03-18', 1639.2),
(1470349059, '2018-03-19', 1034.2),
(1811434639, '2018-03-19', 1642.45),
(1470349059, '2018-03-20', 1029.74),
(1811434639, '2018-03-20', 1642.12),
(1470349059, '2018-03-21', 1033.16),
(1811434639, '2018-03-21', 1643.31);

-- --------------------------------------------------------

--
-- Table structure for table `jenis_transaksi`
--

CREATE TABLE `jenis_transaksi` (
  `id` tinyint(1) UNSIGNED NOT NULL,
  `jenis_transaksi` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jenis_transaksi`
--

INSERT INTO `jenis_transaksi` (`id`, `jenis_transaksi`) VALUES
(1, 'pembelian'),
(2, 'penjualan'),
(3, 'pengalihan');

-- --------------------------------------------------------

--
-- Table structure for table `klien`
--

CREATE TABLE `klien` (
  `id` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `nomor_ponsel` varchar(20) NOT NULL,
  `penghasilan_pertahun` bigint(20) UNSIGNED NOT NULL,
  `id_profil_resiko` tinyint(1) UNSIGNED NOT NULL,
  `bank` varchar(70) NOT NULL,
  `cabang` varchar(70) NOT NULL,
  `nomor_rekening` varchar(70) NOT NULL,
  `nama_pemilik_rekening` varchar(100) NOT NULL,
  `id_mata_uang` char(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `klien`
--

INSERT INTO `klien` (`id`, `email`, `password`, `tanggal_lahir`, `nomor_ponsel`, `penghasilan_pertahun`, `id_profil_resiko`, `bank`, `cabang`, `nomor_rekening`, `nama_pemilik_rekening`, `id_mata_uang`) VALUES
('7bca52fb54da17b7b0ea4f25af2c7c02', 'rizqiirfan23@gmail.com', '60f73b0e259e97160e1e4b30b384fa9f2299f7af', '2010-03-01', '089898989898', 2000000000, 3, 'bni', 'bandung', '1230819998', '16', 'idr'),
('b98b0c0c0a23210a9b77e2a02b35a818', 'klien2@gmail.com', '7ac787f78b499df07d9aca8221fb2a72280723ed', '1997-09-16', '57567675656774', 360000, 2, 'BNI', 'UB', '674712834297', 'klien2', 'IDR'),
('c97ebb3665342196c4da7c524a7754a8', 'klien@gmail.com', 'f091d4696a7d0b3b7dc32fdb1a0adf26572491d5', '1999-02-03', '09937139232', 100000, 3, 'BRI', 'UM', '9999999999', 'klien1', 'IDR');

-- --------------------------------------------------------

--
-- Table structure for table `mata_uang`
--

CREATE TABLE `mata_uang` (
  `id_mata_uang` char(3) NOT NULL,
  `nama_mata_uang` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mata_uang`
--

INSERT INTO `mata_uang` (`id_mata_uang`, `nama_mata_uang`) VALUES
('IDR', 'Rupiah Indonesia');

-- --------------------------------------------------------

--
-- Stand-in structure for view `perkembangan`
-- (See below for the actual view)
--
CREATE TABLE `perkembangan` (
`id_reksadana` int(30)
,`tanggal` date
,`nab` float
,`reksadana` varchar(200)
);

-- --------------------------------------------------------

--
-- Table structure for table `profil_resiko`
--

CREATE TABLE `profil_resiko` (
  `id` tinyint(1) UNSIGNED NOT NULL,
  `profil_resiko` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profil_resiko`
--

INSERT INTO `profil_resiko` (`id`, `profil_resiko`) VALUES
(1, 'Rendah'),
(2, 'Menengah'),
(3, 'Tinggi');

-- --------------------------------------------------------

--
-- Table structure for table `reksadana`
--

CREATE TABLE `reksadana` (
  `id` int(30) NOT NULL,
  `reksadana` varchar(200) NOT NULL,
  `jenis` varchar(20) NOT NULL,
  `nab` float UNSIGNED NOT NULL,
  `1bln` decimal(5,2) NOT NULL,
  `1th` decimal(5,2) NOT NULL,
  `YTD` decimal(5,2) NOT NULL,
  `5thn` decimal(5,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reksadana`
--

INSERT INTO `reksadana` (`id`, `reksadana`, `jenis`, `nab`, `1bln`, `1th`, `YTD`, `5thn`) VALUES
(1470349059, 'Avrist Balanced - Amar Syariah', 'Campuran', 1036.57, '-0.83', '3.95', '-0.09', '0.00'),
(1811434639, 'BNI-AM Dana Pasar Uang Kemilau', 'Pasar Uang', 1642.9, '0.43', '6.28', '1.05', '0.00');

-- --------------------------------------------------------

--
-- Table structure for table `status_transaksi`
--

CREATE TABLE `status_transaksi` (
  `id` tinyint(1) UNSIGNED NOT NULL,
  `status_transaksi` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status_transaksi`
--

INSERT INTO `status_transaksi` (`id`, `status_transaksi`) VALUES
(0, 'transaksi gagal'),
(1, 'menunggu pembayaran klien'),
(2, 'menunggu konfirmasi admin bank'),
(3, 'menunggu konfirmasi admin reksadana'),
(4, 'transaksi selesai');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id` varchar(100) NOT NULL,
  `id_jenis_transaksi` tinyint(1) UNSIGNED NOT NULL,
  `waktu` datetime NOT NULL,
  `id_klien` varchar(200) NOT NULL,
  `id_reksadana` int(30) NOT NULL,
  `id_reksadana_tujuan` int(30) NOT NULL,
  `unit` bigint(20) UNSIGNED NOT NULL,
  `nilai_transaksi` bigint(20) UNSIGNED DEFAULT NULL,
  `biaya_admin` int(11) UNSIGNED NOT NULL,
  `total` bigint(20) UNSIGNED NOT NULL,
  `id_admin_bank` int(11) NOT NULL,
  `id_admin_reksadana` int(11) NOT NULL,
  `id_status_transaksi` tinyint(1) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id`, `id_jenis_transaksi`, `waktu`, `id_klien`, `id_reksadana`, `id_reksadana_tujuan`, `unit`, `nilai_transaksi`, `biaya_admin`, `total`, `id_admin_bank`, `id_admin_reksadana`, `id_status_transaksi`) VALUES
('016d0ccf21ecb005d0063044ff45a536', 2, '2018-03-20 21:17:52', '7bca52fb54da17b7b0ea4f25af2c7c02', 1811434639, 0, 5, 8172, 0, 8172, 0, 0, 3),
('156ea03f374fb019c4043b7ad9196732', 1, '2018-03-20 21:56:43', '7bca52fb54da17b7b0ea4f25af2c7c02', 1470349059, 0, 12, 12481, 126, 12607, 1, 0, 3),
('501e9f0370d255dcb765d1b523c838e9', 2, '2018-03-21 19:03:20', '7bca52fb54da17b7b0ea4f25af2c7c02', 1811434639, 0, 12, 19721, 0, 19721, 0, 0, 3),
('530adea644ff9478ea5c8ea3517c6c4b', 1, '2018-03-20 19:23:26', '7bca52fb54da17b7b0ea4f25af2c7c02', 1811434639, 0, 21, 34318, 344, 34662, 1, 1, 4),
('5feced00dc18a5136dcc57b45f24e40d', 1, '2018-03-20 23:08:25', '7bca52fb54da17b7b0ea4f25af2c7c02', 1470349059, 0, 31, 32241, 323, 32564, 0, 0, 2),
('69af4cacead633c44ddb63f0617d60cb', 3, '2018-03-22 09:04:28', '7bca52fb54da17b7b0ea4f25af2c7c02', 1811434639, 1470349059, 11, NULL, 0, 0, 0, 1, 4),
('8231f5c7de0aa207a3c19812b0bc002e', 1, '2018-03-20 17:39:11', '7bca52fb54da17b7b0ea4f25af2c7c02', 1470349059, 0, 23, 23732, 238, 23970, 1, 1, 4),
('9abee10b6576771cb354534e7155b182', 1, '2018-03-20 23:16:38', '7bca52fb54da17b7b0ea4f25af2c7c02', 1470349059, 0, 12, 12481, 126, 12607, 0, 0, 2),
('bffd41fc7306b581661b59b727e18fa0', 2, '2018-03-20 19:31:55', '7bca52fb54da17b7b0ea4f25af2c7c02', 1470349059, 0, 23, 23921, 0, 23921, 1, 1, 4);

-- --------------------------------------------------------

--
-- Table structure for table `up_klien`
--

CREATE TABLE `up_klien` (
  `id_klien` varchar(200) NOT NULL,
  `id_reksadana` int(30) NOT NULL,
  `up` bigint(20) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `up_klien`
--

INSERT INTO `up_klien` (`id_klien`, `id_reksadana`, `up`) VALUES
('b98b0c0c0a23210a9b77e2a02b35a818', 1470349059, 0),
('7bca52fb54da17b7b0ea4f25af2c7c02', 1470349059, 11),
('c97ebb3665342196c4da7c524a7754a8', 1470349059, 0),
('b98b0c0c0a23210a9b77e2a02b35a818', 1811434639, 0),
('7bca52fb54da17b7b0ea4f25af2c7c02', 1811434639, 10),
('c97ebb3665342196c4da7c524a7754a8', 1811434639, 0);

-- --------------------------------------------------------

--
-- Structure for view `perkembangan`
--
DROP TABLE IF EXISTS `perkembangan`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `perkembangan`  AS  select `history_nab`.`id_reksadana` AS `id_reksadana`,`history_nab`.`tanggal` AS `tanggal`,`history_nab`.`nab` AS `nab`,`reksadana`.`reksadana` AS `reksadana` from (`history_nab` join `reksadana` on((`history_nab`.`id_reksadana` = `reksadana`.`id`))) union select `reksadana`.`id` AS `id_reksadana`,curdate() AS `tanggal`,`reksadana`.`nab` AS `nab`,`reksadana`.`reksadana` AS `reksadana` from `reksadana` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_bank`
--
ALTER TABLE `admin_bank`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_reksadana`
--
ALTER TABLE `admin_reksadana`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `history_nab`
--
ALTER TABLE `history_nab`
  ADD KEY `id_reksadana` (`id_reksadana`);

--
-- Indexes for table `jenis_transaksi`
--
ALTER TABLE `jenis_transaksi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `klien`
--
ALTER TABLE `klien`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_mata_uang` (`id_mata_uang`),
  ADD KEY `id_profil_resiko` (`id_profil_resiko`);

--
-- Indexes for table `mata_uang`
--
ALTER TABLE `mata_uang`
  ADD PRIMARY KEY (`id_mata_uang`);

--
-- Indexes for table `profil_resiko`
--
ALTER TABLE `profil_resiko`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reksadana`
--
ALTER TABLE `reksadana`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `status_transaksi`
--
ALTER TABLE `status_transaksi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_jenis_transaksi` (`id_jenis_transaksi`),
  ADD KEY `id_klien` (`id_klien`),
  ADD KEY `id_reksadana` (`id_reksadana`),
  ADD KEY `id_reksadana_tujuan` (`id_reksadana_tujuan`),
  ADD KEY `id_status_transaksi` (`id_status_transaksi`),
  ADD KEY `id_admin_bank` (`id_admin_bank`),
  ADD KEY `id_admin_reksadana` (`id_admin_reksadana`);

--
-- Indexes for table `up_klien`
--
ALTER TABLE `up_klien`
  ADD KEY `id_klien` (`id_klien`),
  ADD KEY `id_reksadana` (`id_reksadana`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_bank`
--
ALTER TABLE `admin_bank`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `admin_reksadana`
--
ALTER TABLE `admin_reksadana`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `klien`
--
ALTER TABLE `klien`
  ADD CONSTRAINT `klien_ibfk_1` FOREIGN KEY (`id_profil_resiko`) REFERENCES `profil_resiko` (`id`),
  ADD CONSTRAINT `klien_ibfk_2` FOREIGN KEY (`id_mata_uang`) REFERENCES `mata_uang` (`id_mata_uang`);

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`id_klien`) REFERENCES `klien` (`id`),
  ADD CONSTRAINT `transaksi_ibfk_3` FOREIGN KEY (`id_jenis_transaksi`) REFERENCES `jenis_transaksi` (`id`),
  ADD CONSTRAINT `transaksi_ibfk_7` FOREIGN KEY (`id_status_transaksi`) REFERENCES `status_transaksi` (`id`),
  ADD CONSTRAINT `transaksi_ibfk_8` FOREIGN KEY (`id_reksadana`) REFERENCES `reksadana` (`id`);

--
-- Constraints for table `up_klien`
--
ALTER TABLE `up_klien`
  ADD CONSTRAINT `up_klien_ibfk_1` FOREIGN KEY (`id_klien`) REFERENCES `klien` (`id`),
  ADD CONSTRAINT `up_klien_ibfk_2` FOREIGN KEY (`id_reksadana`) REFERENCES `reksadana` (`id`);

DELIMITER $$
--
-- Events
--
CREATE EVENT `change_nab` ON SCHEDULE EVERY 1 MINUTE STARTS '2018-03-20 18:23:03' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
        DECLARE i INT(5);
        SELECT MIN(DATEDIFF(CURDATE(), history_nab.tanggal)) INTO @min_difference FROM history_nab;
        WHILE @min_difference > 1 DO
            SET @min_difference = @min_difference - 1;
            SET i = 0;
            SELECT (CURDATE()-@min_difference) INTO @date;
            SELECT COUNT(*) INTO @count_reksadana FROM reksadana;
            WHILE i < @count_reksadana DO
                SELECT reksadana.id INTO @id FROM reksadana ORDER BY id ASC LIMIT i, 1;
                SELECT reksadana.nab INTO @nab FROM reksadana ORDER BY id ASC LIMIT i, 1;
                SET @new_nab = @nab + (random(-500, 500)/100);
                INSERT INTO history_nab VALUES(@id, @date, @nab);
                UPDATE reksadana SET reksadana.nab = @new_nab WHERE reksadana.id = @id;
                SET i = i + 1;
            END WHILE;
        END WHILE;
    END$$

DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
