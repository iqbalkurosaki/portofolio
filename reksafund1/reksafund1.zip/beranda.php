<?php
require_once('check_access.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Beranada</title>
</head>
<body>
beranda
<a href="logout.php">logout</a>
</body>
</html>