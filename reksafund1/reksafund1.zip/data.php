<?php
if (!session_id()) {
	session_start();
}
require_once 'dynamic_nab.php';
?>
<!DOCTYPE html>
<html>
<head>
<?php
	if ((!isset($_SESSION['akses']) || $_SESSION['akses']!='klien')) {
		echo "<title>Data Reksadana</title>";
	} else {
		echo "<title>Pembelian Reksadana</title>";
	}
?>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<script type="text/javascript" src="js/jquery-1.10.2.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<style type="text/css">
		.hover{
			cursor: pointer;
		}
	</style>
</head>
<body bgcolor="#7F7F7F">
<div class="container" >
	<div style="padding: 25px">
		<a href="index.php"><img src="img/RF.png" style="max-width: 150px;"></a>
	</div>
	<nav class="navbar navbar-default" style="border-radius: 0px;border:none">
		<div class="navbar-header">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
	      <span class="icon-bar"></span>
	      <span class="icon-bar"></span>
	      <span class="icon-bar"></span>                        
	    </button>
		</div>
      <div class="collapse navbar-collapse" id="myNavbar">
<?php
	if (isset($_SESSION['akses'])){
		if ($_SESSION['akses'] == 'klien') {
?>
		    <ul class="nav navbar-nav text-center" id="demo">
		      <li class="active" ><a href="#"><i class="glyphicon glyphicon-plus-sign"></i> PEMBELIAN</a></li>
		      <li ><a href="klien/penjualan.php"><i class="glyphicon glyphicon-minus-sign"></i> PENJUALAN</a></li>
		      <li ><a href="klien/pengalihan.php"><i class="glyphicon glyphicon-share"></i> PENGALIHAN</a></li>
		    </ul>
		    
		      <ul class="nav navbar-nav navbar-right text-center">
			  <li class="dropdown"> 
			  <a class="dropdown-toggle hover" type="button" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span> Hai <?php echo $_SESSION['nama']; ?> </a>
			  <ul class="nav navbar-nav navbar-right dropdown-menu">
			      <li><a href="klien/rincian.php"><span class="glyphicon glyphicon-record"></span> Daftar Transaksi Anda </a></li>
			      <li><a href="klien/reksadana.php"><span class="glyphicon glyphicon-stats"></span> Daftar Reksadana Anda </a></li>
			      <li><a href="klien/profil.php"><span class="glyphicon glyphicon-cog"></span> Lihat Akun Anda </a></li>
			      <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Keluar</a></li>
		      </ul>
		      </li>
			</ul>
<?php
		} else { ?>
		    <ul class="nav navbar-nav navbar-right text-center">
			  <li><a><span class="glyphicon glyphicon-user"></span> Hai <?php echo $_SESSION['nama']; ?></a></li>
			      <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Keluar</a></li>
			</ul>
<?php	}
	} else {
?>
		    <ul class="nav navbar-nav navbar-right text-center">
		    <li><a href="login_page.php"><i class="glyphicon glyphicon-check"></i> Login</a> </li>
			</ul>
		    <ul class="nav navbar-nav text-center" id="demo">
		      <li ><a href="login_page.php"><i class="glyphicon glyphicon-plus-sign"></i> PEMBELIAN</a></li>
		      <li ><a href="login_page.php"><i class="glyphicon glyphicon-minus-sign"></i> PENJUALAN</a></li>
		      <li ><a href="login_page.php"><i class="glyphicon glyphicon-share"></i> PENGALIHAN</a></li>
		    </ul>
<?php
	}
?>
	  </div>
	</nav>
	<div class="col-sm-14">
		<form class="form-inline">
		    <div class="input-group">
		      <input type="email" class="form-control" size="10" placeholder="cari" required>
		      <div class="input-group-btn">
		        <button type="button" class="btn btn-default"><span class="glyphicon glyphicon-search"></span></button>
		      </div>
		    </div>
		    <div class="input-group">
		    	<select class="form-control" id="bank" required>
		    		<option disabled selected> Jenis </option>
				    <option value="bri">Saham</option>
					<option value="bni">Pendapatan Tetap</option>
					<option value="bca">Pasar Uang</option>
					<option value="bni">Campuran</option>
					<option value="bca">Syariah</option>
				  </select>
		    </div>
		  </form>
	</div>
<?php
require_once 'koneksi.php';
if ((isset($_SESSION['akses']) && $_SESSION['akses']=='klien')) {
	$stmt = $db->prepare("SELECT * FROM reksadana WHERE reksadana.id NOT IN (SELECT reksadana.id FROM reksadana INNER JOIN up_klien ON up_klien.id_reksadana = reksadana.id WHERE up_klien.id_klien = ? AND up_klien.up > 0 )");
	$stmt->bindParam(1, $_SESSION['id']);
	$stmt->execute();
} else {
	$stmt = $db->query("SELECT * FROM reksadana");
}
if ($stmt->rowCount() > 0) {
?>
 <div class="row table-responsive" style="margin-left: 5px">
	<h3>Pembelian Reksadana</h3>
	<div style="height: 400px; overflow: scroll;">
		<table class="table table-bordered">
    <thead>
      <tr>
        <th>Nama Reksadana</th>
<?php
	if ((!isset($_SESSION['akses']) || $_SESSION['akses']=='klien')) {
	?>
        <th>Beli</th>
<?php
	}
?>
        <th>Jenis</th>
        <th>NAB</th>
        <th>1 Bulan (%)</th>
		<th>1 Tahun (%)</th>
		<th>YTD (%)</th>
		<th>5 Tahun (%)</th>
		<th>Lihat Perkembangan</th>
      </tr>
    </thead>
    <tbody>
    <?php
    	while ($res = $stmt->fetch()){
			echo "
				<tr>
					<td>".$res[1]."</td>";
			if (!isset($_SESSION['akses'])) { ?>
				<td><button class="btn btn-success" onclick="window.location.href='login_page.php'">Beli</button></td>
<?php
			} elseif ($_SESSION['akses']=='klien') { ?>
				<td><button class="btn btn-success" onclick="window.location.href='klien/beli_reksadana.php?r=<?php echo $res[0]; ?>'">Beli</button></td>
<?php
			}
			echo	"<td>".$res[2]."</td>
					<td>".$res[3]."</td>
					<td>".$res[4]."</td>
					<td>".$res[5]."</td>
					<td>".$res[6]."</td>
					<td>".$res[7]."</td>";
?>
					<td><button class="btn btn-success" onclick="window.location.href='perkembangan.php?r=<?php echo $res[0] ?>'">Lihat</button></td>
				</tr>
<?php
			}
		} else { ?>
			<div class="jumbotron text-center"><h1 style="color: #D7D2D2">Tidak Ada Reksadana Yang Dapat Dibeli</h1> </div>
		<?php
		}
?>
    </tbody>
  </table>
  </div>
  </div>
</div>
<div class="footer text-center">CopyRight &copy; 2018 Reksafund </div>
</body>
</html>