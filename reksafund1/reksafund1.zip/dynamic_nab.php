<?php
require_once 'koneksi.php';
$stmt = $db->query("SELECT MIN(DATEDIFF(CURDATE(), history_nab.tanggal)) FROM history_nab");
$min_difference = $stmt->fetch();
$min_difference = $min_difference[0];
$stmt = $db->query("SELECT COUNT(*) FROM reksadana");
$count_reksadana = $stmt->fetch();
$count_reksadana = $count_reksadana[0];
while ($min_difference > 1) { 
    $min_difference--;
    $date = date('Y-m-d', strtotime((-1*$min_difference).' days'));
    $stmt = $db->query("SELECT reksadana.id, reksadana.nab FROM reksadana ORDER BY id ASC");
    while ($res = $stmt->fetch()) {
        $stmt2 = $db->prepare("INSERT INTO history_nab VALUES(?, ?, ?)");
        $stmt2->bindParam(1, $res['id']);
        $stmt2->bindParam(2, $date);
        $stmt2->bindParam(3, $res['nab']);
        $stmt2->execute();
        $nab = $res['nab'] + (rand(-500, 500)/100);
        $stmt2 = $db->prepare("UPDATE reksadana SET reksadana.nab = ? WHERE reksadana.id = ?");
        $stmt2->bindParam(1, $nab);
        $stmt2->bindParam(2, $res['id']);
        $stmt2->execute();
    }
}
?>