<?php
	if (!session_id()) {
		session_start();
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin Reksadana</title>
</head>
<body>
halaman admin reksadana
hai <?php echo $_SESSION['nama']; ?>
<a href="logout.php">Logout</a>
</body>
</html>