<?php 
if (!session_id()) {
	session_start();
}

require_once 'cek_akses.php';
require_once '../dynamic_nab.php';
require_once '../koneksi.php';
$stmt = $db->prepare("SELECT klien.bank,klien.nomor_rekening,klien.nama_pemilik_rekening,klien.email,klien.nomor_ponsel,transaksi.id, jenis_transaksi.jenis_transaksi, transaksi.waktu, reksadana.reksadana, transaksi.unit, transaksi.nilai_transaksi, transaksi.biaya_admin, transaksi.total, status_transaksi.status_transaksi FROM klien INNER JOIN transaksi INNER JOIN jenis_transaksi INNER JOIN reksadana INNER JOIN status_transaksi ON transaksi.id_jenis_transaksi = jenis_transaksi.id && transaksi.id_reksadana = reksadana.id && transaksi.id_status_transaksi = status_transaksi.id && transaksi.id_klien = klien.id && transaksi.id = ? ORDER BY transaksi.waktu DESC");
$stmt->bindParam(1, $_GET['id']);
$stmt->execute();
$res = $stmt->fetch();
 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<script type="text/javascript" src="../js/jquery-1.10.2.js"></script>
	<script type="text/javascript" src="../js/bootstrap.min.js"></script>
	<script type="text/javascript" src="../js/effec.js"></script>
	<style type="text/css">
		.hover{
			cursor: pointer;
		}
	</style>
</head>
<body>
	<div class="container">
		<div class="row text-center" style="border-bottom: 1px solid #63D300">
			<div style="margin: 25px 0px"><img src="../img/RF.png" class="img-responsive" width="150px" >
			</div>
			<nav class="navbar navbar-default" style="border-radius: 0px;border:none">
				<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
			      <span class="icon-bar"></span>
			      <span class="icon-bar"></span>
			      <span class="icon-bar"></span>                        
			    </button>
				</div>
		      <div class="collapse navbar-collapse" id="myNavbar">
			    <ul class="nav navbar-nav text-center" id="demo">
			      <li class="active" ><a href="../data.php"><i class="glyphicon glyphicon-plus-sign"></i> PEMBELIAN</a></li>
			      <li ><a href="#"><i class="glyphicon glyphicon-minus-sign"></i> PENJUALAN</a></li>
			      <li ><a href="#"><i class="glyphicon glyphicon-share"></i> PENGALIHAN</a></li>
			    </ul>
			    <?php if (isset($_SESSION['akses'])){
			    ?>
			    <ul class="nav navbar-nav navbar-right text-center">
				  <li><a><span class="glyphicon glyphicon-user"></span> Hai <?php echo $_SESSION['nama']; ?> </a></li>
				  <li class="dropdown"> 
				  <a class="dropdown-toggle hover" type="button" data-toggle="dropdown"><i class="glyphicon glyphicon-th"></i></a>
				  <ul class="nav navbar-nav navbar-right dropdown-menu">
				      <li><a href="profil.php"><span class="glyphicon glyphicon-list-alt"></span> Lihat Berkas Anda </a></li>
				      <li><a href="../logout.php"><span class="glyphicon glyphicon-log-out"></span> Keluar</a></li>
			      </ul>
			      </li>
				</ul> 
			    <?php
			    }?>
			  </div>
			</nav>
			<h3>Rincian Pembelian Reksadana <?php echo $res['reksadana'] ?></h3>
			<span class="small text-right" >status : <?php echo $res['status_transaksi']; ?></span>
		</div>
		<div class="row">
			<div class="col-sm-6">
				<table class="table ">
					<thead>
					<tr>
						<th colspan="2"><H3>Data Investor</H3></th>
					</tr>
					</thead>
					<tbody>
					<tr>
						<td>Nama pemilik</td>
						<td>: <?php echo $res['nama_pemilik_rekening']; ?></td>
					</tr>
					<tr>
						<td>No Telepon</td>
						<td>: <?php echo $res['nomor_ponsel']; ?></td>
					</tr>
					<tr>
						<td>Alamat</td>
						<td>: Jl.a</td>
					</tr>
					<tr>
						<td>Email </td>
						<td>: <?php echo $res['email']; ?></td>
					</tr>
					</tbody>
				</table>
				<table class="table ">
					<thead>
					<tr>
						<th colspan="2"><H3>Struk Penjualan</H3></th>
					</tr>
					</thead>
					<tbody>
					<tr>
						<td>ID Transaksi</td>
						<td>: <?php echo $res['id']; ?></td>
					</tr>
					<tr>
						<td>Jenis Transaksi</td>
						<td>: <?php echo $res['jenis_transaksi']; ?></td>
					</tr>
					<tr>
						<td>Waktu Transaksi</td>
						<td>: <?php echo $res['waktu'] ?></td>
					</tr>
					<tr>
						<td>Nama Reksadana</td>
						<td>: <?php echo $res['reksadana'] ?></td>
					</tr>
					<tr>
						<td>Jumlah Unit</td>
						<td>: <?php echo $res['unit']; ?></td>
					</tr>
					<tr>
						<td>Nilai Transaksi</td>
						<td>: Rp <?php echo number_format($res['nilai_transaksi'],2,',','.'); ?> -</td>
					</tr>
					<tr>
						<td>Biaya Admin</td>
						<td>: Rp <?php echo number_format($res['biaya_admin'],2,',','.'); ?> -</td>
					</tr>
					</tbody>
					<tfoot>
					<tr>
						<td><b>Total</td>
						<td>: Rp <?php echo number_format($res['total'],2,',','.'); ?> -</b></td>
					</tr>
					</tfoot>
				</table>
				<table class="table">
					<thead>
					<tr>
						<th colspan='3'><h3>Info Pembayaran</h3></th>
					</tr>
					</thead>
					<tbody>
					<tr>
						<td>No. Rekening</td>
						<td>: <?php echo $res['nomor_rekening']; ?></td>
					</tr>
					<tr>
						<td>Bank</td>
						<td>: <?php echo $res['bank']; ?></td>
					</tr>
					<tr>
						<td>a/n</td>
						<td>: PT. Reksafund</td>
					</tr>
					</tbody>
				</table>
			</div>
		</div>
		<div class="row">
			
		</div>
	</div>
</body>
</html>