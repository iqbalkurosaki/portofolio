<?php
if (!session_id()) {
	session_start();
}
require_once 'cek_akses.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Klien</title>
</head>
<body>
halaman klien
<br />
hai <?php echo isset($_SESSION['nama']) ? $_SESSION['nama'] : ''; ?>
<br />
<a href="../data.php">Pembelian reksadana</a>
<br />
<a href="daftar_transaksi.php">Lihat Daftar Transaksi</a>
<br />
<a href="../logout.php">Logout</a>
<div class="footer text-center">CopyRight &copy; 2018 Reksafund </div>
</body>
</html>