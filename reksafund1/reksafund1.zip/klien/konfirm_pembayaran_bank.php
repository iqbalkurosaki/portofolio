<?php
if (!session_id()){
	session_start();
}
require_once 'cek_akses.php';
require_once '../dynamic_nab.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
Sudah Transfer Ke <br>
Nama Bank : <input type="text" value="<?php echo ?>">
<?php
require_once '../koneksi.php';
$stmt = $db->prepare("SELECT * FROM reksadana WHERE id = ?");
$stmt->bindParam(1, $_GET['r']);
$stmt->execute();
$res = $stmt->fetch();
if ($res[0]!=NULL) {
	echo "pembelian reksadana ".$res[0];
?>
<form method="POST">
	<input type="hidden" name="id" value="<?php echo $res[0]; ?>">
	Nama Reksadana : <input type="text" name="reksadana" value="<?php echo $res[1]; ?>">  <!-- input didisable !-->
	NAB per unit : <input type="number" name="nab" value="<?php echo $res[3]; ?>"> <!-- input didisable !-->
	Jumlah Unit Penyertaan yang ingin dibeli : <input type="number" name="up" min="1">
	Total Pembayaran : <input type="number" name="total_bayar"> <!-- input didisable, diisi otomatis lewat javascript !-->
	<input type="submit" name="Beli" value="beli">
	
</form>
<?php
} else {
	echo "reksadana tersebut tidak tersedia";
}
?>
</body>
</html>