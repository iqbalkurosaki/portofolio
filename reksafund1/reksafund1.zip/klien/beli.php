<?
if (!session_id()) {
	session_start();
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Pembelian Reksadana</title>
</head>
<body>
<table>
	<tr>
		<th>Nama Reksadana</th>
		<th>Beli</th>
		<th>Jenis</th>
		<th>NAB</th>
		<th>1 Bulan (%)</th>
		<th>1 Tahun (%)</th>
		<th>YTD (%)</th>
		<th>5 Tahun (%)</th>
	</tr>
<?php
require_once '../koneksi.php';
$stmt = $db->query("SELECT * FROM reksadana");
while ($res = $stmt->fetch()){
	echo "
	<tr>
		<td>".$res[1]."</td>"; ?>
		<td><button onclick="window.location.href='beli_reksadana.php?r=<?php echo $res[0]; ?>'">Beli</button></td>
		<?php
echo	"<td>".$res[2]."</td>
		<td>".$res[3]."</td>
		<td>".$res[4]."</td>
		<td>".$res[5]."</td>
		<td>".$res[6]."</td>
		<td>".$res[7]."</td>
	</tr>";
}
?>
</table>
</body>
</html>