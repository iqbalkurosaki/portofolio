<?php
	if (!session_id()) {
		session_start();
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin Bank</title>
</head>
<body>
halaman admin bank
hai <?php echo $_SESSION['nama']; ?>
<a href="logout.php">Logout</a>
</body>
</html>