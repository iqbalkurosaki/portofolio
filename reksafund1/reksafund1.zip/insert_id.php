<?php
// require_once 'koneksi.php';
// 	$stmt = $db->query("SELECT reksadana FROM reksadana2");
// 	while ($res = $stmt->fetch()) {
// 			$stmt2 = $db->prepare("UPDATE reksadana2 SET id = ? WHERE reksadana = ?");
// 			$id = crc32($res['reksadana']);
// 			$stmt2->bindParam(1, $id);
// 			$stmt2->bindParam(2, $res['reksadana']);
// 			$stmt2->execute();
// 	}

echo crc32("Aberdeen Syariah Proteksi Insha 1");
?>